# 		Session共享

## 一、创建工程，引入依赖

引入web、spring session以及redis依赖

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-redis</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-web</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.session</groupId>
    <artifactId>spring-session-data-redis</artifactId>
</dependency>

<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-test</artifactId>
    <scope>test</scope>
</dependency>
```

项目目录

![image-20220919212119275](Session共享.assets\image-20220919212119275.png)



## 二、配置application.yml

主要配置与redis相关的属性

```yml
spring:
  #配置redis
  redis:
    #配置主机号
    host: 127.0.0.1
    #配置端口号
    port: 6379
    #配置密码
    password: 123456
    #配置数据库索引（默认为0）
    database: 1
server:
  #设置端口号，方便区分
  port: 8080
```

## 三、创建一个简单的demo

### 1、创建一个简单的controller类

为了方便区分每次获取服务的是那个端口号，这里专门把端口号给输出了。

```java
@RestController
public class HelloController {

    @Value("${server.port}")
    Integer port;
    @GetMapping("/set")
    public String set(HttpSession session){
        session.setAttribute("name","sicnu");
        return String.valueOf(port);
    }

    @GetMapping("/get")
    public String get(HttpSession session){
        return session.getAttribute("name") +":"+port;
    }
}
```



### 2、执行打包命令

执行maven生命周期的打包命令

<img src="Session共享.assets\image-20220919205710470.png" alt="image-20220919205710470" style="zoom: 67%;" />

### 3、在控制台运行打包出来的jar包

在控制台中运行jar包，使用 `java -jar 包名`的命令

![image-20220919210048210](Session共享.assets\image-20220919210048210.png)

### 4、将application.yml的端口号改为8989，使用idea运行

```xml
server:
  #设置端口号，方便区分
  port: 8989
```



![image-20220919210508573](Session共享.assets\image-20220919210508573.png)



### 5、访问端口号为8080的实例的[localhost:8080/set](http://localhost:8080/set)

![image-20220919211940705](Session共享.assets\image-20220919211940705.png)

### 6、观察redis

观察redis可以发现session已经存入了。

<img src="Session共享.assets/image-20220919213257971.png" alt="image-20220919213257971" style="zoom:67%;" />

<img src="Session共享.assets\image-20220919212418292.png" alt="image-20220919212418292" style="zoom:67%;" />



### 7、访问端口号为8989的[localhost:8989/get](http://localhost:8989/get)

![image-20220919211922848](Session共享.assets\image-20220919211922848.png)

此时可以发现session在两个端口成功的共享了。也可以认为在两个服务器运行成功了，毕竟我暂时没有两台电脑。